-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2018 at 04:05 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'News', '2018-06-07 04:55:45', '2018-06-07 04:55:45'),
(2, 'Videos', '2018-06-07 04:55:45', '2018-06-07 04:55:45'),
(3, 'Discussion', '2018-06-07 04:55:45', '2018-06-07 04:55:45'),
(4, 'Tutorials', '2018-06-07 04:55:45', '2018-06-07 04:55:45'),
(5, 'Newsletter', '2018-06-07 04:55:45', '2018-06-07 04:55:45'),
(6, 'Laravel', '2018-06-07 05:06:39', '2018-06-07 05:06:39'),
(7, 'Mongo Db', '2018-06-07 05:09:37', '2018-06-07 05:09:37');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(17, '2014_10_12_000000_create_users_table', 1),
(18, '2014_10_12_100000_create_password_resets_table', 1),
(19, '2018_05_21_115957_create_posts_table', 1),
(20, '2018_05_21_120022_create_categories_table', 1),
(21, '2018_05_24_122320_create_tags_table', 1),
(22, '2018_05_24_123012_create_post_tag_tabel', 1),
(23, '2018_05_25_090858_create_profiles_table', 1),
(24, '2018_06_02_075638_create_settings_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `slug`, `content`, `featured`, `category_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'The Important & Standard Post Format', 'the-important-standard-post-format', '<h2>What is Lorem Ipsum?</h2>\r\n\r\n<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<h2>Why do we use it?</h2>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2>Where does it come from?</h2>\r\n\r\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.</p>\r\n\r\n<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from &quot;de Finibus Bonorum et Malorum&quot; by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>\r\n\r\n<h2>Where can I get some?</h2>\r\n\r\n<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#39;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>', 'uploads/posts/15283674371.png', 2, NULL, '2018-06-07 05:00:37', '2018-06-07 05:00:37'),
(2, 'SVG Animation Made Easy With Hot New Tool SVGator', 'svg-animation-made-easy-with-hot-new-tool-svgator', '<p>The best format for images on the web in 2018 is SVG. Not only is SVG resolution-independent&mdash;meaning that SVG graphics stay crisp at any size, on any device&mdash;but SVG file sizes are smaller than other competing formats.</p>\r\n\r\n<p>One of the most popular features of SVG is the ability to access parts of the graphic with code, and use CSS to change properties like fill color. But did you know that you can also embed animation code in an SVG file?</p>\r\n\r\n<p>Animating SVG can be complex, and requires some pretty intricate code to get right. Until now that is, because with the amazing <a href=\"https://www.svgator.com\">SVGator</a> you can actually design SVG animations, right in your browser.</p>\r\n\r\n<p>Since its launch a little over 7 months ago SVGator has won legions of fans for its simple-to-use interface, and the quality of the modular code that it outputs.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2>Get Started with SVGator</h2>\r\n\r\n<p>You can get started with SVGator like this: First, create your SVG file in your favorite graphics application&mdash;you could use Sketch, or Illustrator, or even hand-code the SVG in your favorite code editor. Next, log into the SVGator site (<a href=\"https://www.svgator.com\">create a account</a> if you don&rsquo;t already have one). Finally, click the &ldquo;Import SVG&rdquo; button to bring your graphic into the editor. Once your graphic&rsquo;s in place you&rsquo;re ready to start animating.</p>\r\n\r\n<p>The user interface will be familiar to anyone who&rsquo;s ever used an animation application, which keeps the learning-curve of picking up SVGator shallow. In the center of the screen you&rsquo;ll see your SVG graphic. On the left you&rsquo;ll see the different elements of your design separated into a list. On the right you&rsquo;ll see a contextual properties panel that changes depending on which element you have selected. Along the bottom of the UI is the timeline that separates elements in the graphic into different channels, and allows you to animate different parts of your graphic independently.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2>Animating with SVGator</h2>\r\n\r\n<p>It&rsquo;s incredibly simple to animate graphics in SVGator. Just select an element from the elements list, and add it to the timeline, then assign one or more animators to it; alternately with an element selected, add an animator and both the element and the animator will be added to the timeline. You can now add keyframes to the animators and set their properties.</p>', 'uploads/posts/15283676672.png', 2, NULL, '2018-06-07 05:04:27', '2018-06-07 05:04:27'),
(3, '3 SEO “Hacks” to Boost Your Website Ranking', '3-seo-hacks-to-boost-your-website-ranking', '<p>Looking to boost your search rankings?</p>\r\n\r\n<p>While nothing can help you reach an audience better than great content, there are simple habits that can help you boost search ranking and provide valuable information for users. And it doesn&rsquo;t require a complete website overhaul or hiring an SEO expert.</p>\r\n\r\n<p>Here are three hacks to help you boost your website ranking and help more users find your website content.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2>1. Use Video and Transcription</h2>\r\n\r\n<p>You might already know that video is a great way to engage with users on your website. From full-screen video headers to short clips to grab attention, moving images can provide information to users that still photos can&rsquo;t. Video can be more than that as well. Use video for tutorials or how-to features to drive even more engagement.</p>\r\n\r\n<p>Often in website design, we use the phrase &ldquo;show, don&rsquo;t tell&rdquo; to describe the design process. The same can be true for whatever your website is about as well. Create a video that provides a valuable resource for users. It could be a video that shows them how to use a product (if you have an ecommerce website) or how to do or make something related to your content area.</p>\r\n\r\n<p>Make sure to create a high quality video. It should provide complete information in a concise way &ndash; so that users will actually watch it.</p>\r\n\r\n<p>Upload the video to your website and make sure to include appropriate metadata (it works much like uploading photos with alt information and appropriate naming). Make sure to include a thumbnail that&rsquo;s visually appealing and shows something interesting. This &ldquo;tiny picture&rdquo; can entice users to watch the video. (Try to include a person in the image to give it a personal feel.)</p>\r\n\r\n<p>Next, create a full transcript of the video and include it on the page with the video itself. (Think of the design like this: big video at the top of the page, header with the title of the video and then full text of the video.)</p>\r\n\r\n<p>This works in two ways:</p>\r\n\r\n<ul>\r\n	<li>It makes the video accessible to more people because they can read the information (great if they are on your website without sound).</li>\r\n	<li>It allows search bots to actually scrape the full content of the video, thanks to the text transcription. (Bots can&rsquo;t actually read what&rsquo;s in the actual video, only the meta data associated with it.)</li>\r\n</ul>\r\n\r\n<p>Make each page with video content unique. Don&rsquo;t use the same video and transcription on multiple pages of the website. It should have its own page and location. <a href=\"https://www.ted.com/talks/john_maeda_on_the_simple_life/transcript\">TED (shown below)</a> does a great job with this, making videos easily accessible &ndash; and easy to search and find &ndash; for all users.</p>', 'uploads/posts/1528367723404-img.png', 2, NULL, '2018-06-07 05:05:23', '2018-06-07 05:05:23'),
(4, 'A Stand-Alone Laravel Slack Package', 'a-stand-alone-laravel-slack-package', '<p>The <code>gpressutto5/laravel-slack</code> composer package is a Slack notification library for Laravel 5.5 by Guilherme Pressutto:</p>\r\n\r\n<blockquote>\r\n<p>Slack notification for Laravel as it should be. Easy, fast, simple and highly testable. Since it uses On-Demand Notifications, it requires Laravel 5.5 or higher.</p>\r\n</blockquote>\r\n\r\n<p>You can install this dependency in your Laravel &gt;= 5.5 application with the following:</p>\r\n\r\n<pre>\r\n<code>composer require gpressutto5/laravel-slack\r\n</code></pre>\r\n\r\n<p>You can publish the configuration file with:</p>\r\n\r\n<pre>\r\n<code>php artisan vendor:publish --provider=&quot;Pressutto\\LaravelSlack\\ServiceProvider&quot;\r\n</code></pre>\r\n\r\n<p>You will also need to configure an <a href=\"https://api.slack.com/incoming-webhooks\">incoming webhook</a> integration for your Slack team.</p>\r\n\r\n<h2>Basic Usage</h2>\r\n\r\n<p>Here&rsquo;s an example of the API interface for the provided Slack service that ships with this package:</p>\r\n\r\n<pre>\r\n<code>// Send a message to a channel\r\n\\Slack::to(&#39;#finance&#39;)-&gt;send(&#39;Hey, finance channel! A new order was created just now!&#39;);\r\n\r\n// Send message to users\r\n\\Slack::to([&#39;@zoe&#39;, &#39;@amy&#39;, &#39;@mia&#39;])\r\n    -&gt;send(&#39;Here is an example message sent to multiple users&#39;);\r\n</code></pre>\r\n\r\n<p>You can mix it up sending a message to both users and channels at the same time:</p>\r\n\r\n<pre>\r\n<code>\\Slack::to(&#39;#support&#39;, &#39;@bill&#39;, &#39;#dev&#39;)\r\n    -&gt;send(&#39;:thinking_face:&#39;);\r\n</code></pre>\r\n\r\n<p>You can even send to a user by passing an Eloquent model that has a <code>slack_channel</code> property, or you can provide an accessor method:</p>\r\n\r\n<pre>\r\n<code>class User extends Model\r\n{\r\n    public function getSlackChannelAttribute(): string\r\n    {\r\n        return $this-&gt;attributes[&#39;my_custom_slack_channel_column&#39;];\r\n    }\r\n}\r\n\\Slack::to(User::where(&#39;verified&#39;, true))\r\n    -&gt;send(&#39;Sending message to all verified users!&#39;);\r\n</code></pre>\r\n\r\n<p>Here&rsquo;s a reference to all the configuration values at the time of writing:</p>\r\n\r\n<pre>\r\n<code>&lt;?php\r\n\r\nreturn [\r\n    &#39;slack_webhook_url&#39; =&gt; env(&#39;SLACK_WEBHOOK_URL&#39;, &#39;&#39;),\r\n    &#39;default_channel&#39; =&gt; &#39;#general&#39;,\r\n    &#39;application_name&#39; =&gt; env(&#39;APP_NAME&#39;, null),\r\n    &#39;application_image&#39; =&gt; null,\r\n];\r\n</code></pre>\r\n\r\n<h2>Testing</h2>\r\n\r\n<p>You can easily mock the Slack service by calling <code>Slack::fake()</code> and messages will not be sent to Slack but will be stored in an array. The package ships with some testing helper methods to aid your tests, for example:</p>\r\n\r\n<pre>\r\n<code>Slack::assertSent(function (SlackMessage $message) {\r\n    return $message-&gt;content === &#39;fake&#39;;\r\n});\r\n\r\nSlack::assertSentCount(3);\r\n</code></pre>\r\n\r\n<h2>Learn More</h2>\r\n\r\n<p>Check out the <a href=\"https://github.com/gpressutto5/laravel-slack\">official GitHub repository</a> and the readme to learn more about this package, including how to write tests for the functionality provided by this package.</p>', 'uploads/posts/15283678325.jpg', 6, NULL, '2018-06-07 05:07:12', '2018-06-07 05:07:12'),
(5, 'Laravel View Components Package', 'laravel-view-components-package', '<p>We featured <a href=\"https://laravel-news.com/introducing-view-components-on-laravel-an-alternative-to-view-composers\">View Components in Laravel</a>, written by Jeff Ochoa, as an alternative approach to View Composers.</p>\r\n\r\n<p>Inspired by Jeff&rsquo;s article, Sebastian De Deyne of Spatie created a Laravel package that brings the concept of a View Component to Laravel applications. The package headline is: &ldquo;A better way to connect data with view rendering in Laravel.&rdquo;</p>\r\n\r\n<p>One of the nice things about this approach over using view composers, is that view components help organize logic and data tied to a view in one place:</p>\r\n\r\n<blockquote>\r\n<p>The benefit over view composers is that data and rendering logic are explicitly tied together in components instead of being connected afterwards. They also allow you to seamlessly combine properties and dependency injection.</p>\r\n</blockquote>\r\n\r\n<h2>Overview</h2>\r\n\r\n<p>The overall concept of a view component, is using the <code>@render</code> directive in a template. For example:</p>\r\n\r\n<pre>\r\n<code>@render(App\\Http\\ViewComponents\\NavigationComponent::class, [&#39;backgroundColor&#39; =&gt; &#39;black&#39;])\r\n</code></pre>\r\n\r\n<p>The first argument in the <code>@render</code> directive ties back to a class that implements the <code>HtmlAble</code> contract. For example, the following component is from the package&rsquo;s readme:</p>\r\n\r\n<pre>\r\n<code>namespace App\\Http\\ViewComponents;\r\n\r\nuse Illuminate\\Http\\Request;\r\nuse Illuminate\\Contracts\\Support\\Htmlable;\r\n\r\nclass NavigationComponent implements Htmlable\r\n{\r\n    /** \\Illuminate\\Http\\Request */\r\n    private $request;\r\n\r\n    /** @var string */\r\n    private $backgroundColor;\r\n\r\n    public function __construct(Request $request, string $backgroundColor)\r\n    {\r\n        $this-&gt;request = $request;\r\n        $this-&gt;backgroundColor = $backgroundColor;\r\n    }\r\n\r\n    public function toHtml(): string\r\n    {\r\n        return view(&#39;components.navigation&#39;, [\r\n            &#39;activeUrl&#39; =&gt; $this-&gt;request-&gt;url(),\r\n            &#39;backgroundColor&#39; =&gt; $this-&gt;backgroundColor,\r\n        ]);\r\n    }\r\n}\r\n</code></pre>\r\n\r\n<h2>Rendering</h2>\r\n\r\n<p>You can render view components by referencing the component&rsquo;s fully qualified name (as seen above), or a string class name:</p>\r\n\r\n<pre>\r\n<code>@render(&#39;navigationComponent&#39;, [&#39;backgroundColor&#39; =&gt; &#39;black&#39;])\r\n</code></pre>\r\n\r\n<p>Since the component can be anything that implements the <code>HtmlAble</code> contract, you are not required to only using blade views to render components. Check the package&rsquo;s readme for an example of wrapping an HTML package in a component.</p>\r\n\r\n<h2>Learn More</h2>\r\n\r\n<p>Check out the <a href=\"https://github.com/spatie/laravel-view-components\">GitHub project</a> to learn more about using this package. I&rsquo;d also encourage you to read the original post on <a href=\"https://laravel-news.com/introducing-view-components-on-laravel-an-alternative-to-view-composers\">view components in Laravel</a> that inspired this package.</p>', 'uploads/posts/15283678736.jpg', 6, NULL, '2018-06-07 05:07:53', '2018-06-07 05:07:53'),
(6, 'The UK\'s 100,000 Genome Project reaches the halfway stage', 'the-uks-100000-genome-project-reaches-the-halfway-stage', '<p>The project has now reached its halfway point, with over 50,000 genomes sequenced. By the end of 2018, the 100,000 genomes project will be complete, with more than 20 petabytes of data stored on the project&#39;s infrastructure.</p>\r\n\r\n<p>The aim is to harness the power of whole genome sequencing technology to transform the way people are cared for, through the development of new and more effective personalised treatments for patients.</p>\r\n\r\n<p><img alt=\"mongodb-dev-ittycheria-ceo.jpg\" src=\"https://zdnet4.cbsistatic.com/hub/i/r/2018/04/11/47812033-0b5d-4243-a327-0990eeb2ad4b/resize/370xauto/8d92de898e46e1d817d4ac688c984ea7/mongodb-dev-ittycheria-ceo.jpg\" style=\"height:auto; width:370px\" /></p>\r\n\r\n<p>Dev Ittycheria, president and CEO of MongoDB.</p>\r\n\r\n<p>Photo: MongoDB</p>\r\n\r\n<p>Patients&#39; genomic data is combined with their clinical data to enable interpretation and analysis. This data is also open to researchers and clinicians studying how best to use genomics in healthcare.</p>\r\n\r\n<p>The amount of data being processed is enormous. According to MongoDB, the project is sequencing on average 1,000 genomes per week which is producing about 10TB of data per day. To manage this complex and sensitive data set, Genomics England uses <a href=\"https://www.mongodb.com/products/mongodb-enterprise-advanced\">MongoDB Enterprise Advanced</a> as a component of its computing platform.</p>\r\n\r\n<p>&quot;Managing clinical and genomic data at this scale and complexity has presented interesting challenges,&quot; said Augusto Rendon, director of bioinformatics at Genomics England. &quot;Adopting MongoDB has been vital to getting the 100,000 Genomes Project off the ground. It has provided us with great flexibility to store and analyse these complex data sets together.&quot;</p>\r\n\r\n<p>According to MongoDB the project&#39;s data platforms were built from the ground up. Why MongoDB? The document database was chosen for three core reasons, the company said. The first was the database&#39;s &quot;native ability to handle a wide variety of data types, even those data structures that weren&#39;t considered at the beginning of the project.&quot;</p>\r\n\r\n<p>This should make it simpler for developers and data scientists to evolve data models and develop software solutions.</p>\r\n\r\n<p><strong>See also: <a href=\"http://www.techproresearch.com/article/culture-automation-and-self-service-the-keys-to-big-data-success/\">Culture, automation and self-service: The keys to big data success</a></strong></p>\r\n\r\n<p>The second reason was performance at scale. It became clear that there would be a massive and constantly growing dataset &quot;that would need to seamlessly scale across underlying compute resources&quot;, the company said. Not only would the data set be big and complex, but the researchers would need to easily explore the data and not have long waits for simple queries.</p>\r\n\r\n<p>The third driver was MongoDB&#39;s features such as end-to-end encryption and fine-grained access control to data.</p>\r\n\r\n<p>The 100,000 Genomes Project dataset is sensitive: as well as the full genetic makeup of a patient, it also includes their clinical features and lifetime health data. Instead, <a href=\"https://www.genomicsengland.co.uk/the-100000-genomes-project/data/\">de-identified</a> data is analysed within a secure, monitored environment. Obviously, this makes encryption and data security vital.</p>\r\n\r\n<h3>Recent and related coverage</h3>\r\n\r\n<p><a href=\"https://www.zdnet.com/article/ibms-watson-health-illumina-team-up-on-genomics-sequencing-cancer-research/\"><strong>IBM&#39;s Watson Health, Illumina team up on genomics sequencing, cancer research</strong></a></p>\r\n\r\n<p>The general idea of the partnership is to cut the expense and time required for cancer researchers to interpret genetic variants across 170 genes.</p>\r\n\r\n<p><a href=\"https://www.zdnet.com/article/intel-helps-advance-genomics-analytics-with-new-architecture/\"><strong>Intel helps advance genomics analytics with new architecture</strong></a></p>\r\n\r\n<p>After committing $25 million to a partnership with the Broad Institute, Intel announces some milestones that should advance genomics research into cancer and other diseases.</p>\r\n\r\n<p><a href=\"https://www.zdnet.com/article/ibms-compute-storage-tech-powers-qatar-genome-program/\"><strong>IBM&#39;s compute, storage tech powers Qatar Genome Program</strong></a></p>\r\n\r\n<p>According to IBM, the Qatar Genome Program is one of the world&#39;s largest national genome medical research projects.</p>\r\n\r\n<p><a href=\"https://www.zdnet.com/article/conways-law-and-healthcare-data-management-genome-data-blockchain-and-gdpr/\"><strong>Conway&#39;s Law and the future of healthcare data management: Genome, Blockchain, and GDPR</strong></a></p>\r\n\r\n<p>Maladies in healthcare data management are obvious, but what about solutions? From selling Genome data to using Blockchain and the effects of GDPR, would we rather stick to the devil we know?</p>\r\n\r\n<p><strong><a href=\"https://www.cnet.com/news/2018-science-space-nasa-climate-genetic-engineering-geoengineering/\">Genes to geoengineering: 4 science stories to watch in 2018</a> </strong>(CNET)</p>\r\n\r\n<p>The New Year could bring us closer to the fountain of youth and to proof we&#39;re not alone in the universe. And that&#39;s not all.</p>\r\n\r\n<p><a href=\"https://www.techrepublic.com/article/how-ai-and-next-generation-genomic-sequencing-is-helping-cancer-patients/\"><strong>How AI and next-generation genomic sequencing is helping cancer patients</strong></a> (TechRepublic)</p>\r\n\r\n<p>Sophia Genetics uses artificial intelligence to pinpoint gene mutations behind cancers and rare disorders to help healthcare providers prescribe the best treatments for patients.</p>', 'uploads/posts/15283680353.jpg', 7, NULL, '2018-06-07 05:10:35', '2018-06-07 05:10:35'),
(7, 'MongoDB gets support for multi-document ACID transactions', 'mongodb-gets-support-for-multi-document-acid-transactions', '<p><a href=\"https://www.mongodb.com/\" target=\"_blank\">MongoDB</a> is finally getting support for multi-document <a href=\"https://en.wikipedia.org/wiki/ACID\" target=\"_blank\">ACID (atomicity, consistency, isolation, durability) transactions</a>. That&rsquo;s something the MongoDB community has been asking for for years and MongoDB Inc, the company behind the project, is now about to make this a reality.</p>\r\n\r\n<p>As the company will announce at an event later today, support for ACID transactions will launch when it ships version 4.0 of its NoSQL database in the summer. Until then, developers can <a href=\"https://www.mongodb.com/transactions\" target=\"_blank\">use a beta</a>, though, to see how they can make use of this new feature.</p>\r\n\r\n<p>At its core, MongoDB is a document database and &mdash; almost by default &mdash; these kind of databases aren&rsquo;t ACID compliant, especially when it comes to multi-document transactions (at the document level, MongoDB already supports ACID transactions). For the most part, that&rsquo;s not a big deal for companies that use database systems like MongoDB because they are not trying to write to multiple documents at the same time.</p>\r\n\r\n<p>Because of this, though, many MongoDB users still run relational databases in parallel with their document database.</p>\r\n\r\n<p>Indeed, as MongoDB co-founder and CTO Eliot Horowitz told me, that was one of the main motivations behind this project. &ldquo;The reason we didn&rsquo;t need this is because the document model negates the need for ACID transactions &mdash; not for all of them, but for most of them,&rdquo; he told me. But at the same time, there are clearly use cases where developers wants transactions for their mission critical use cases. Horowitz also argues that some developers who start working with MongoDB &ldquo;have this nagging fear that they may need it in the future.&rdquo; This launch obvious takes that fear away.</p>\r\n\r\n<p>&ldquo;Transactional guarantees have been a critical feature for relational databases for decades, but have typically been absent from non-relational alternatives, which has meant that users have been forced to choose between transactions and the flexibility and versatility that non-relational databases offer,&rdquo; said Stephen O&rsquo;Grady, Principal Analyst with RedMonk. &ldquo;With its support for multi-document ACID transactions, MongoDB is built for customers that want to have their cake and eat it too.&rdquo;</p>\r\n\r\n<p>Horowitz stressed that he doesn&rsquo;t believe developers will simply turn this feature on by default and that most will only enable it for very specific use cases. &ldquo;I don&rsquo;t expect this to be a common way to write to MongoDB,&rdquo; he told me.</p>\r\n\r\n<p>Building this new feature was a multi-year effort that started with the <a href=\"https://www.mongodb.com/press/wired-tiger\" target=\"_blank\">acquisition of WiredTiger</a>&nbsp;and that company&rsquo;s database storage engine three years ago. To enable it, the team touched virtually every component of the database system.</p>', 'uploads/posts/1528368419Mongo.jpg', 7, NULL, '2018-06-07 05:16:59', '2018-06-07 05:16:59'),
(8, 'MongoDB launches Atlas on AWS Marketplace – hopes to woo cloud buyers', 'mongodb-launches-atlas-on-aws-marketplace-hopes-to-woo-cloud-buyers', '<p>NoSQL database provider MongoDB has announced even closer ties with cloud giant AWS, making its cloud managed service Atlas available through the AWS Marketplace. It is hoped that this will make it easier for large enterprise buyers to purchase MongoDB Atlas, by streamlining the buying process and the purchasing decision.</p>\r\n\r\n<p>Atlas was l<a href=\"https://diginomica.com/2016/06/28/mongodb-finally-takes-cloud-into-its-own-hands-with-launch-of-atlas/\">aunched as a database-as-a-service offering in June of 2016</a>, with the aim at the time to woo customers away from buying MongoDB from third party cloud providers (but still being hosted on AWS, Google and Azure).</p>\r\n\r\n<p>I got the chance to speak to MongoDB CTO and co-founder Eliot Horowitz, who took the time to fill diginomica in on the news from the AWS re:Invent event in Las Vegas this week. The sell at the time was that MongoDB Atlas is &ldquo;operated by the experts who design and engineer the database&rdquo; meaning that &ldquo;developers no longer need to worry about operational tasks such as hardware provisioning, failure recovery, software patching, upgrades, configuration or backups&rdquo;.</p>\r\n\r\n<p>However, before touching on the Atlas/AWS Marketplace tie-up, I was keen to find out how MongoDB was fairing after its successful IPO last month in New York &ndash; where the company ended up 34% above its IPO price of $24 on the first day of trading to $32 (it has since dropped to around $28).</p>\r\n\r\n<p>Horowitz was enthused by the results of the IPO and said that it provides certainty for customers that MongoDB is here for the long-term. He said:</p>\r\n\r\n<blockquote>\r\n<p>The IPO went really well. We were happy that the market reception was very good. In terms of why, I think it&rsquo;s a number of reasons. One, as a company we are ready from a financial standpoint, from a cultural standpoint, from a market standpoint, the database market is quite big and the market really understands that, so it just made a lot of sense.</p>\r\n\r\n<p>And I think that overall it&rsquo;s actually a good thing, it&rsquo;s been really well received by our customers, who appreciate knowing that we are stable and are going to be here for the long term. In terms of what it is going to change, not too much on the day to day basis, we are still committed to our core beliefs, but what it does do is give our customers confidence that we are going to be around for a long time. That we are going to be building the database of the future, not of the next five minutes.</p>\r\n</blockquote>\r\n\r\n<h2>An easier purchasing decision</h2>\r\n\r\n<p>Horowitz said that the aim of making Atlas available on the AWS Marketplace is that customers that have gone all in with Amazon, don&rsquo;t then have to think about a separate budget or billing process to buy Mongo Atlas. Instead this can be all grouped together &ndash; making the purchasing decision easier for large enterprise buyers. He explained:</p>\r\n\r\n<blockquote>\r\n<p>What&rsquo;s happened for us and a lot of our clients, especially with Amazon, is they&rsquo;re buying large amounts of AWS services and use MongoDB. If you sign up for a large enterprise deal with Amazon, and you&rsquo;ve already gone through the procurement process, you can now easily buy MongoDB Atlas through the Marketplace. It just makes it easier.</p>\r\n\r\n<p>You don&rsquo;t have to think about your spend differently, you can sort of sign up for your big AWS spend and you can use Amazon products or Atlas on top of Amazon. It all just works the same, it&rsquo;s all built the same.</p>\r\n</blockquote>\r\n\r\n<p>I asked Horowitz if buying through the AWS Marketplace meant lower margins for MongoDB &ndash; as opposed to buying it directly &ndash; but he wasn&rsquo;t willing to comment beyond saying that &ldquo;it&rsquo;s not a bad thing [for Mongo] and it&rsquo;s something that we want to happen, it&rsquo;s not something we are scared of&rdquo;.</p>\r\n\r\n<p>There are also feature-set advantages to buying Atlas via AWS, according to Horowitz. He explained:</p>\r\n\r\n<blockquote>\r\n<p>The combination of Amazon and Atlas, a feature that came out six weeks ago, is cross-region Atlas clusters, which I think is a pretty interesting feature. You can have a single Atlas cluster that spans multiple regions, those regions can be for high availability, so if an entire region goes down your database is still up. Or for local reads &ndash; so you can use US as your main database, then you can put a secondary in London, Japan, Sydney, so that you can reduce your latency. That&rsquo;s a pretty interesting one.</p>\r\n</blockquote>\r\n\r\n<h2>Going forward</h2>\r\n\r\n<p>Following the IPO, I was also keen to hear from Horowitz what Mongo has planned for the coming months. He said that most of the development work will focus on its core database and the recent release of Stitch &ndash; a backend-as-a-service platform (<a href=\"https://diginomica.com/2017/06/20/mongodb-moves-stack-backend-service-platform-stitch/\">read our write up here</a>). Also, the focus on developers&rsquo; ease of use will continue to be key. He said:</p>\r\n\r\n<blockquote>\r\n<p>I think what you will see from us is especially a lot of the same. A lot of focus on developer features. I still believe that developers are the heart to everything. And making databases that make developers more productive is the best thing we can do and our strong suit.</p>\r\n\r\n<p>I think then it will be a cross combination of the core database and on Stitch &ndash; we are doing a lot of investment on Stitch. You will see a lot of the developers writing those applications, whether they&rsquo;re IoT, mobile or web-based applications, it&rsquo;s a pretty big thing. And we are quite bold on Atlas, we&rsquo;ve got quite an interesting roadmap for Atlas in the next 12 months.</p>\r\n</blockquote>\r\n\r\n<p>However, challenges remain, most notably the competition. Horowitz added:</p>\r\n\r\n<blockquote>\r\n<p>I think the biggest challenges are that we are still not as big as Amazon or Google. We are now public, which is great. But we are still not as big as the other players. So we&rsquo;ve just got to be at the top of our game.</p>\r\n\r\n<p>We have some inherent advantages &ndash; there&rsquo;s no vendor lock in, you can use Atlas on any cloud, those sorts of things are good inherent advantages that we have. So that&rsquo;s something that we think about a lot, which most people do in the software space nowadays.</p>\r\n</blockquote>', 'uploads/posts/1528368533mongodb-375x228.png', 7, NULL, '2018-06-07 05:18:53', '2018-06-07 05:18:53'),
(9, 'The simple guide to deploy Laravel 5 application on shared hosting', 'the-simple-guide-to-deploy-laravel-5-application-on-shared-hosting', '<p>For more about deploying a Laravel/Lumen application on shared hosting, check out my complete guide, <a href=\"https://github.com/petehouston/laravel-deploy-on-shared-hosting\" target=\"_blank\">https://github.com/petehouston/laravel-deploy-on-shared-hosting</a></p>\r\n\r\n<hr />\r\n<p>Changelog</p>\r\n\r\n<ul>\r\n	<li><strong>12/Jun/2015</strong>: Adding symlink as response from @<a href=\"http://medium.com/@rverrips\" target=\"_blank\">rverrips</a>, add optimization command for production environment pointed out by <a href=\"https://medium.com/@constb\" target=\"_blank\">@constb</a>.</li>\r\n</ul>\r\n\r\n<hr />\r\n<p>In this tutorial, I&rsquo;d like to show you a very simple method to deploy Laravel 5 applications, safe &amp; secure.</p>\r\n\r\n<p>First, let say in your hosting server (VPS, or shared hosting&hellip;whatever), you have current <strong>www/</strong> directory, which is accessible publicly via web domain, for example:</p>\r\n\r\n<pre>\r\n<strong>/Users/petehouston/www/</strong></pre>\r\n\r\n<p>Now, create a new directory, which contains all your application source code, at the same level as <strong>www/</strong>, for example:</p>\r\n\r\n<pre>\r\n<strong>/Users/petehouston/project/</strong></pre>\r\n\r\n<p>You can use <em>git, svn, mecurial</em> or whatever method you like to transfer your code to this directory.</p>\r\n\r\n<p>At this point, you can see that the project code is apparently not accessible to the web, right?</p>\r\n\r\n<p>Next step is to copy all contents inside the <strong>/project/public</strong> directory to <strong>www/</strong> directory. The easy example is that, with the fresh Laravel 5 installation application, the <strong>project/public/index.php</strong> should be copied to the <strong>www/index.php</strong>&nbsp;, have you got the point?</p>\r\n\r\n<p>Remember to copy the <strong>public/.htaccess</strong> to the <strong>www/</strong> also. Don&rsquo;t forget this, it is very important for your app routes. Without it, your routes won&rsquo;t be working and there will be a blank or empty page in every route.</p>\r\n\r\n<p>Now let&rsquo;s modify the www/index.php to reflect the new structure. Don&rsquo;t modify the <strong>project/public/index.php</strong>, okay? Only modify <strong>www/index.php</strong>, remember this!!!</p>\r\n\r\n<p>Find the following line</p>\r\n\r\n<pre>\r\n<strong>require __DIR__.&rsquo;/../bootstrap/autoload.php&rsquo;;</strong></pre>\r\n\r\n<pre>\r\n<strong>$app = require_once __DIR__.&rsquo;/../bootstrap/app.php&rsquo;;</strong></pre>\r\n\r\n<p>And update them to the correct paths as following</p>\r\n\r\n<pre>\r\n<strong>require __DIR__.&rsquo;/../project/bootstrap/autoload.php&rsquo;;</strong></pre>\r\n\r\n<pre>\r\n<strong>$app = require_once __DIR__.&rsquo;/../project/bootstrap/app.php&rsquo;;</strong></pre>\r\n\r\n<p>It worths to mention that some shared hosting service providers allow symlink to the <strong>public_html</strong> directory of the main domain, we can simplify the process, instead of copying the whole <strong>project/public/</strong> to <strong>/www</strong>, we create symbolic linking,</p>\r\n\r\n<pre>\r\n<strong>ln -s /Users/petehouston/project/public /Users/petehouston/www</strong></pre>\r\n\r\n<p>Almost done, it is time to set permissions for the project/storage directory, it should be writable.</p>\r\n\r\n<pre>\r\n<strong>$ chmod -R o+w project/storage</strong></pre>\r\n\r\n<p>The final step is here, config your application variables in the <strong>project/.env</strong>&nbsp;.</p>\r\n\r\n<p>All righty right! Everything should work now.</p>\r\n\r\n<p>If you don&rsquo;t have composer installed already on your server, you can easily grab it to the project directory then.</p>\r\n\r\n<pre>\r\n<strong>$ cd /User/petehouston/project/</strong></pre>\r\n\r\n<pre>\r\n<strong>$ curl -sS </strong><a href=\"https://getcomposer.org/installer\" target=\"_blank\"><strong>https://getcomposer.org/installer</strong></a><strong> | php &mdash; &ndash;filename=composer</strong></pre>\r\n\r\n<p>Now you can execute composer to manage dependencies.</p>\r\n\r\n<pre>\r\n<strong>$ php composer install</strong></pre>\r\n\r\n<pre>\r\n<strong>$ php composer dumpautoload -o</strong></pre>\r\n\r\n<pre>\r\n<strong>$ php artisan config:cache</strong></pre>\r\n\r\n<pre>\r\n<strong>$ php artisan route:cache</strong></pre>\r\n\r\n<p>From now on, each time you deploy, I mean you update the <strong>project/</strong> directory, you will need to reflect all changes in <strong>project/public/</strong> directory into <strong>www/</strong>, except the <strong>www/index.php</strong>, which is already configured above to include the correct paths.</p>\r\n\r\n<p>You can easily achieve this via bash shell command line. I wrote this little script<a href=\"https://gist.github.com/petehouston/32ae937e3b7bfab3b7a2#file-sync-sh\" target=\"_blank\"> <strong>sync.sh</strong></a>, you can use this by putting into the same directory level with <strong>project/</strong> and <strong>www/</strong></p>\r\n\r\n<pre>\r\n<strong>$ pwd</strong></pre>\r\n\r\n<pre>\r\n<strong>/Users/petehouston/project</strong></pre>\r\n\r\n<pre>\r\n<strong>$ cd ..</strong></pre>\r\n\r\n<pre>\r\n<strong>$ pwd</strong></pre>\r\n\r\n<pre>\r\n<strong>/Users/petehouston</strong></pre>\r\n\r\n<pre>\r\n<strong>$ ls</strong></pre>\r\n\r\n<pre>\r\n<strong>project/ www/ sync.sh</strong></pre>\r\n\r\n<pre>\r\n<strong>$ chmod +x sync.sh</strong></pre>\r\n\r\n<pre>\r\n<strong>$ ./sync.sh</strong></pre>', 'uploads/posts/1528371686laravel.jpg', 6, NULL, '2018-06-07 06:11:26', '2018-06-07 06:11:26');

-- --------------------------------------------------------

--
-- Table structure for table `post_tag`
--

CREATE TABLE `post_tag` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post_tag`
--

INSERT INTO `post_tag` (`id`, `post_id`, `tag_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 2, 2, NULL, NULL),
(3, 3, 1, NULL, NULL),
(4, 4, 2, NULL, NULL),
(5, 5, 2, NULL, NULL),
(6, 6, 3, NULL, NULL),
(7, 7, 3, NULL, NULL),
(8, 8, 3, NULL, NULL),
(9, 9, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about` text COLLATE utf8mb4_unicode_ci,
  `user_id` int(11) NOT NULL,
  `facebook` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `avatar`, `about`, `user_id`, `facebook`, `youtube`, `created_at`, `updated_at`) VALUES
(1, 'uploads/avatar/1.png', 'dbkjasd kjhkjd kjhkjd khkjdakjkjh dahkjh dakjhkjhd ahkjhdakjhkjdakjhdsakhkjdhsa', 1, 'www.facebook.com', 'www.youtube.com', '2018-06-07 04:55:45', '2018-06-07 04:55:45');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `site_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `contact_number`, `contact_email`, `address`, `created_at`, `updated_at`) VALUES
(1, 'Laravel\'s Blog', '123456789', 'ranjith@gmail.com', 'No6 New buston Layout, coimbatore', '2018-06-07 04:55:45', '2018-06-07 04:55:45');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `tag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `tag`, `created_at`, `updated_at`) VALUES
(1, 'CMS', '2018-06-07 04:55:45', '2018-06-07 04:55:45'),
(2, 'Framework', '2018-06-07 04:55:45', '2018-06-07 04:55:45'),
(3, 'Database', '2018-06-07 04:55:45', '2018-06-07 04:55:45');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `admin`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Ranjith Shivasami', 'ranjith@gmail.com', 1, '$2y$10$XRElpmW1t0b3wGprfcf2e.t0BF9LSCIrF/GAWaZiIbNOYPx4Lv6FS', NULL, '2018-06-07 04:55:45', '2018-06-07 04:55:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_tag`
--
ALTER TABLE `post_tag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `post_tag`
--
ALTER TABLE `post_tag`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
